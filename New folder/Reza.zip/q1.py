#5*2 + 1/2
a = 5 * 2
b = 1 / 2
result = a + b
print(result)
#(3<2) + 7*(4 != 5) 
#True = 1, False =0
c=(3<2)
d=7*(4!=5)
result=c+d
print(result)
print((3 < 2) + 7 * (4 != 5))
#3>5 or 5>3 
F=3>5
E=5>3
print(F or E )
#3+7>>2 
a = 3 + 7
b = a >> 2
print(b)
#5*2 + 1/2.
a = 5 * 2
b = 1 / 2.
result = a + b
print(result)
#3<2 + 7*4 != 5 
c=3<2
d=7*4!=5
result=c+d
print(result)
print(3 < 2 + 7 * 4 != 5)
#5>4 and 7<1 
H=5>4
J=7<1
print(H and J)
#not 3 or 2>1 
a = not 3
b = 2 > 1
result = a or b
print(result)
#not 'a'
a = not 'a'
print(a)
#7%2 * 2-7**(3-1)
a = 7 % 2
b = a * 2
c = 3 - 1
d = 7 ** c
result = b - d
print(result)
#100000000000 
a = 100000000000
print(a)
