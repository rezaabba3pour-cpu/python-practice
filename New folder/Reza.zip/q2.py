a = 5
b = '7'
c = 4.0

k = a
print(k)

a = b
print(a)

b = a
print(b)

c = a + b
print(c)

a = k
print(a)

a = c
print(a)

c = k
print(c)
