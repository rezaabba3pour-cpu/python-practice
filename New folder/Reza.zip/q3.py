a = 5
b = '7'
c = 4.0
#print(a + b) #type a and b  is differnt. عدد و رشته
a = 5
b = '7'
c = 4.0
#يک رشته ضربدعدد برابر است تعداد رشته ضربدر عدد
print(a * b)
a = 5
b = '7'
c = 4.0
print(a + a)
a = 5
b = '7'
c = 4.0
print(a + c)
a = 5
b = '7'
c = 4.0
#print(b + c) # جمع رشته با اعشاري انجام نميشه
a = 5
b = '7'
c = 4.0
print(b + b) # دو رشته کنار هم
a = 5
b = '7'
c = 4.0
#print(b * b)  مجاز نيست
a = 5
b = '7'
c = 4.0
print(b + '9')
a = 5
b = '7'
c = 4.0
print(int(a + c))
a = 5
b = '7'
c = 4.0
print(float(b) * a)
a = 5
b = '7'
c = 4.0
print(str(a) + b)
a = 5
b = '7'
c = 4.0
#print(len(a) + c) تابع len() فقط روی رشته، لیست، تاپل و... کار می‌کند.
a = 5
b = '7'
c = 4.0
print(type(b) == type('a'))
a = 5
b = '7'
c = 4.0
#print(type(long(b)))
a = 5
b = '7'
c = 4.0
print(not a != 9)
a = 5
b = '7'
c = 4.0
print(a > c and int(b) > a)
a = 5
b = '7'
c = 4.0
print(b > 'a')
a = 5
b = '7'
c = 4.0
print(a >> 1)
